# Copyright (c) 2022 Arista Networks, Inc.
# Use of this source code is governed by the Apache License 2.0
# that can be found in the COPYING file.
 
from time import sleep
 
duration = ctx.action.args.get("duration")
# User timeout arg is a string, convert it to an integer. If not specified, default to 60 seconds
duration = int(duration) if duration else 60
 
# Sleep for the desired duration`
sleep(duration)
